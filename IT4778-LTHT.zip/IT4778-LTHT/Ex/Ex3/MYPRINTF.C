#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>


union REGS R;
struct SREGS sR;

void putStr(char* msg){
	int i=0;
	while(msg[i]!='\0'){			// can modify to handle case zero-leading integer
		R.h.ah=0x0e;
		R.h.bh=0;
		R.h.al=msg[i];
		int86x(0x10,&R,&R,&sR);
		i++;
	}
   //printf("\nDone");
}


char* toHex(int n){
	char dig[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	int pos=7;
	/// n - 32bit integer
	char* result;
	result = (char *) malloc(9);
	result[8]='\0';

	while(n){
		result[pos]=dig[n%16];
		pos--;
		n/=16;
	}
	do {
		result[pos]='0';
	} while(pos--);

	//cout << result << endl;

	return result;
}

void putHex(int n){
	putStr(toHex(n));

}

char* toDec(int n){
	char dig[] ={'0','1','2','3','4','5','6','7','8','9'};
	char* result = (char *) malloc(11);
	int pos=9;
	result[10]='\0';

	while(n){
		result[pos]=dig[n%10];
		pos--;
		n/=10;
	}
	do {
		result[pos]='0';
	} while(pos--);

	return result;
}
void putInt(int n){
	putStr(toDec(n));
}

int checkType(char* format){
	char type = format[1];        // default format.length=2
	//printf("%c",type);
	if(type=='s') return 1;
	else if(type=='d') return 2;
	else if(type=='x') return 3;
	else return -1;
}

void _printf(int type, va_list ap, char* format){
	int n;
	char* ss;
   //	printf("%d",type);
	if(type==1){
		ss = va_arg(ap,char *);
		putStr(ss);
		//printf("%s",ss);
	}
	else if(type==2){
		n = va_arg(ap,int);
		//printf("%d",n);
		putInt(n);
	}
	else if(type==3){
		n = va_arg(ap,int);
		//printf("%d",n);
		putHex(n);
	}
	else if(type==-1){
		// eg printf("ABCXYZ"), one parameter
		putStr(format);
	}
}


void myPrintf(const char* format, ...){
	va_list arg;
   //	printf("%s",format);
	va_start(arg,format);
	_printf(checkType(format),arg,format);
	va_end(arg);
}

int main(){
	clrscr();
	printf("This line print by default printf() function !!!.");
	myPrintf("%s","This line print by myPrintf() function !!!.");
	myPrintf("%d",1234);		// n<= 10^9
	myPrintf("Special case of printf().");
	//myPrintf("%x",1234);
	getch();
	return 0;

}