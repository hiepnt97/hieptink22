/**
!------------------------------------------------------------------------------
! ~ Ten 	    :   Nguyen Van Thanh - MSSV 20122401 - nvthanh1994@gmail.com
!------------------------------------------------------------------------------
! ~ Mon hoc     :   LTHT-IT4778
! ~ Bai         :   EX1
!------------------------------------------------------------------------------
*/

#include <bits/stdc++.h>
using namespace std;


/// 1.1
char* toBinary(int n){
    /// n - 32bit integer
    char* result;
    result = new char[33];
    result[32]='\0';

    int pos=31;
    while(n){
        if(n%2==0) result[pos]='0';
        else result[pos]='1';
        pos--;
        n/=2;
    }
    do {
        result[pos]='0';
    } while(pos--);
    //cout << result << endl;

    return result;
}
char* toHex(int n){
    char dig[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

    /// n - 32bit integer
    char* result;
    result = new char[9];
    result[8]='\0';

    int pos=7;
    while(n){
        result[pos]=dig[n%16];
        pos--;
        n/=16;
    }
    do {
        result[pos]='0';
    } while(pos--);

    //cout << result << endl;

    return result;
}

/// 1.2
unsigned setBit(unsigned mask, unsigned pos){
    mask|=(1<<pos);
    return mask;
}
unsigned clrBit(unsigned mask, unsigned pos){
    mask&=~(1<<pos);
    return mask;
}

/// 1.3
int cntBit(int n){
    //return __builtin_popcount(n);
    int cnt=0;
    while(n){
        if(n%2) cnt++;
        n/=2;
    }
    return cnt;
}

/// 1.4
int ROR(int n){
    /// n - 32bit integer
    // rightshift + set lai bit cuoi cung
    return (n>>1)|(n<<31);
}
int ROL(int n){
    return (n<<1)|(n>>31);
}

/// 1.5
unsigned toDate(int d, int m, int y){
    /// 4 bit dau la thang, 5 bit sau la ngay, 7 bit cuoi la nam (+1980)
    return (d<<12)|(m<<7)|(y-1980);
}

/// 1.6
unsigned extractDate(int dmy){
    return dmy>>12;
}
unsigned extractMonth(int dmy){
    int temp=dmy>>7;
    return temp&(0x1F);
}
unsigned extractYear(int dmy){
    return (dmy&(0x3F))+1980;
}


int main(){
    cout << toBinary(1234) << endl;
    cout << toHex(1234) << endl;

    cout << toDate(4,9,2015) << endl;   // 17571
    cout << extractDate(17571) << endl;
    cout << extractMonth(17571) << endl;
    cout << extractYear(17571) << endl;














    return 0;
}
