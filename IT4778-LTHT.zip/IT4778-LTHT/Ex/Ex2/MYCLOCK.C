#include<dos.h>
#include<conio.h>
#include <time.h>

#define intr 0x1C

void interrupt(*oldhandler)();

void print_string(char* s) {
    // printf("%s",s);
    unsigned char far * Ptr = MK_FP(0xB800,0000);
    int i;
    for(i=0; i<24; i++) {
        Ptr[56+i<<1]=s[i];
        //Ptr[56+i<<1|1]=s[i+1];
    }
}

void interrupt handler(time_t cur_time) {
    time(&cur_time);
    clrscr();
    print_string(ctime(&cur_time));
}



int main(void) {
    time_t cur_time;
    oldhandler=getvect(intr);
    setvect(intr,handler);
    getch();
    setvect(intr,oldhandler);
    return 0;
}
