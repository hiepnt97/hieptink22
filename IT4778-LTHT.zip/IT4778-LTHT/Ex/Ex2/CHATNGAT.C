#include<dos.h>
#define intr 0x09
void interrupt(*oldhandler)();
int count = 0;
void interrupt handler(){
	unsigned al=inportb(0x60);
	count++;
	if(count%2==1)
	sound(al*50);
	else nosound();
	oldhandler();
}
int main(void){
	oldhandler=getvect(intr);
	setvect(intr,handler);
	while(count<20);
	nosound();
	setvect(intr,oldhandler);
	return 0;
}